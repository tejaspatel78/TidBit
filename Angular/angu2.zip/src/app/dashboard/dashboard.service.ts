import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(
    private http: HttpClient
  ) { }

  fetchEvents() {
    const url = 'http://localhost:3000/api/project/fetch/event'
    return this.http.get(url).pipe(map((res) => {
      return Object(res);
    }));
  }
}
