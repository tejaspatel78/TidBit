import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginService } from './login.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private _loginService: LoginService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  login(email, password) {
    this._loginService.authenticateUser(email, password).subscribe(response => {
      console.log('EEEEE', response);
      if (response.data.length > 0) {
        this.router.navigate(['/dashboard']);
      }
    })
  }

}
