import { Component, OnInit } from '@angular/core';
import { RegisterService } from './register.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  public role;

  constructor(
    private _registerService: RegisterService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  onItemChange(value) {
    this.role = value;
  }
  
  signup(username, email, password) {
    this._registerService.registerUser(username, email, password, this.role).subscribe(response => {
      if (response.data.length > 0) {
        this.router.navigate(['/dashboard']);
      }
    })
  }

}
