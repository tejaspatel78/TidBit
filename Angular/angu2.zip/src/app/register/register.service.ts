import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(
    private http: HttpClient
  ) { }

  registerUser(username, email, password, role) {
    const url = 'http://localhost:3000/api/project/user/signUp'
    const body = {
      username: username,
      email: email,
      password: password,
      role: role
    }
    return this.http.post(url, body).pipe(map((res) => {
      return Object(res);
    }));
  }
}
