const eventSchema = require('../services/event')
const httpStatusCode = require('http-status-codes')
const { responseGenerators, pino } = require('../lib/utils')
const logger = pino({ level: 'debug' });

const fetchEvent = async (req, res) => {
    try {
        const userCode = req.headers.user_code
        const response = await eventSchema.fetchEvent(userCode)
        return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, 'Event fetched successfully', false))
    } catch (error) {
        logger.warn(`Error while fetch event. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while fetch Event', true))
    }
}

const addEvent = async (req, res) => {
    try {
        const userCode = req.headers.user_code
        const response = await eventSchema.addEvent(req.body, userCode)
        if (Array.isArray(response) && response.length > 0) {
            return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, 'Event added successfully', false))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.METHOD_NOT_ALLOWED, response, false))
    } catch (error) {
        logger.warn(`Error while add event. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while add Event', true))
    }
}

const editEvent = async (req, res) => {
    try {
        const userCode = req.headers.user_code
        const eventId = req.params.event_id
        const response = await eventSchema.editEvent(req.body, eventId, userCode)
        if(!response || response.nModified === 0) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, 'You are not allowed to do this action', false))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, 'Event edited successfully', false))
    } catch (error) {
        logger.warn(`Error while edit event. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while edit Event', true))
    }
}

const applyEvent = async (req, res) => {
    try {
        const userCode = req.headers.user_code
        const eventId = req.params.event_id
        const response = await eventSchema.applyEvent(eventId, userCode)
        if (Array.isArray(response) && response.length > 0) {
            return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, 'Event applied successfully', false))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.METHOD_NOT_ALLOWED, response, false))
    } catch (error) {
        logger.warn(`Error while add event. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while applying for Event', true))
    }
}

module.exports = {
    fetchEvent,
    addEvent,
    editEvent,
    applyEvent
}