'use strict'

require('../models/event')
require('../models/user')
const { pino, connect, bcrypt } = require('../lib/utils')
const logger = pino({ level: 'debug' });

const fetchEvent = async (userCode, start, limit) => {
    try {
        logger.debug('fetchEvent() userCode: %s, start: %s, limit:%s', userCode, start, limit)
        const json = {}
        const db = await connect('tidbit_db')
        const eventModel = db.model('event')
        const userModel = db.model('users')
        const userData = await userModel.find({
            user_id: userCode
        })
        if (userData[0].role === 'Admin') {
            json.created_by = userCode
        } else if (userData[0].role === 'Client') {
            json.status = true
        }
        const EventDetail = await eventModel.find(json)
        return EventDetail
    } catch (error) {
        logger.warn(`Error while fetchEvent(). Error = %j %s`, error, error)
        throw error
    }
}

const addEvent = async (reqPayload, userCode) => {
    try {
        logger.debug('addEvent() reqPayload: %j, userCode: %s', reqPayload, userCode)
        const db = await connect('tidbit_db')
        const eventModel = db.model('event')
        const userModel = db.model('users')
        const userData = await userModel.find({
            user_id: userCode
        })
        if (userData[0].role === 'Client') {
            return 'You are not allowed to do this action'
        }
        const response = await eventModel.insertMany({
            name: reqPayload.name,
            description: reqPayload.description,
            place: reqPayload.place,
            event_start_date: reqPayload.event_start_date,
            event_end_date: reqPayload.event_end_date,
            created_by: userCode
        })
        return response
    } catch (error) {
        logger.warn(`Error while addEvent(). Error = %j %s`, error, error)
        throw error
    }
}

const editEvent = async (reqPayload, eventId, userCode) => {
    try {
        logger.debug('editEvent() reqPayload: %j, eventId: %s', reqPayload, eventId)
        const db = await connect('tidbit_db')
        const eventModel = db.model('event')
        const userModel = db.model('users')
        const userData = await userModel.find({
            user_id: userCode
        })
        if (userData[0].role === 'Client') {
            return false
        }
        const response = await eventModel.update({ event_id: eventId, created_by: userCode }, {
            $set: {
                name: reqPayload.name,
                description: reqPayload.description,
                place: reqPayload.place,
                event_start_date: reqPayload.event_start_date,
                event_end_date: reqPayload.event_end_date,
                status: reqPayload.status
            }
        })
        return response
    } catch (error) {
        logger.warn(`Error while editEvent(). Error = %j %s`, error, error)
        throw error
    }
}

const applyEvent = async (eventId, userCode) => {
    try {
        logger.debug('applyEvent() eventId: %s, userCode: %s', eventId, userCode)
        const db = await connect('tidbit_db')
        const eventModel = db.model('event')
        const userModel = db.model('users')
        const userData = await userModel.find({
            user_id: userCode
        })
        if (userData[0].role === 'Admin') {
            return 'You are not allowed to do this action'
        }
        const response = await eventModel.update({ event_id: eventId }, {
            $push: {
                user_applied: Number(userCode),
            }
        })
        return response
    } catch (error) {
        logger.warn(`Error while addEvent(). Error = %j %s`, error, error)
        throw error
    }
}

module.exports = {
    fetchEvent,
    addEvent,
    editEvent,
    applyEvent
}