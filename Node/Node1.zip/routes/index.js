const usersRoute = require('./user');
const placesRoute = require('./event');

module.exports = function(app) {
  app.use('/api/project', usersRoute)
  app.use('/api/project', placesRoute)
}
