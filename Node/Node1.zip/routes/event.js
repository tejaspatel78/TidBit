const express = require('express');
const router = express.Router();
const eventController = require('../controllers/event')
const { verifyToken } = require('../middlewares/verifyToken')

router.get('/fetch/event', verifyToken, eventController.fetchEvent);
router.post('/add/event', verifyToken, eventController.addEvent);
router.post('/edit/event/:event_id', verifyToken, eventController.editEvent);
router.get('/apply/event/:event_id', verifyToken, eventController.applyEvent);

module.exports = router;
