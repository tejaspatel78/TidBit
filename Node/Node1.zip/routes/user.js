const express = require('express');
const router = express.Router();
const userController = require('../controllers/user')

router.post('/user/signUp', userController.userSignup);
router.post('/user/login', userController.userLogin);

module.exports = router;
