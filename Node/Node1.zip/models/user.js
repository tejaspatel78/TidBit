'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema
require('mongoose-long')(mongoose)
const SchemaTypes = mongoose.Schema.Types
const { autoIncrement } = require('../lib/utils')

const userdataSchema = new Schema({
  user_id: {
    type: SchemaTypes.Long,
    required: true
  },
  username: {
    type: String,
    required: false
  },
  email: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    required: true
  }
})

userdataSchema.plugin(autoIncrement.plugin, {
  model: 'users',
  field: 'user_id',
  startAt: 1
})

module.exports = mongoose.model('users', userdataSchema)
