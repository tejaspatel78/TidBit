'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema
require('mongoose-long')(mongoose)
const SchemaTypes = mongoose.Schema.Types
const { autoIncrement } = require('../lib/utils')

const eventSchema = new Schema({
  event_id: {
    type: SchemaTypes.Long,
    required: true
  },
  name: {
    type: String,
    required: false
  },
  description: {
    type: String,
    required: true
  },
  place: {
    type: String,
    required: true
  },
  event_start_date: {
    type: Date,
    required: true
  },
  event_end_date: {
    type: Date,
    required: true
  },
  created_by: {
    type: Number,
    required: true
  },
  created_on: {
    type: Date,
    default: Date.now
  },
  user_applied: {
    type: Array,
    default: []
  },
  status: {
    type: Boolean,
    default: true
  }
})

eventSchema.plugin(autoIncrement.plugin, {
  model: 'event',
  field: 'event_id',
  startAt: 1
})

module.exports = mongoose.model('event', eventSchema)
